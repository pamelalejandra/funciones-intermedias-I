#1.Actualizar valores en diccionarios y listas
x = [ [5,2,3], [10,8,9] ] 
x[1][0] = 15
print(x)

print("---")

estudiantes = [
    {'first_name':  'Michael', 'last_name' : 'Jordan'},
    {'first_name' : 'John', 'last_name' : 'Rosales'}
]
estudiantes[0]['last_name']= 'Bryant'
print(estudiantes)

print("---")

directorio_deportes = {
    'basketball' : ['Kobe', 'Jordan', 'James', 'Curry'],
    'fútbol' : ['Messi', 'Ronaldo', 'Rooney']
}
directorio_deportes['fútbol'][0] = 'Andrés'
print(directorio_deportes)

print("---")

z = [ {'x': 10, 'y': 20} ]
z[0]['y'] = 30
print(z)

print("---")

#2.Iterar a través de una lista de diccionarios
def iterar_diccionarios(estudiantes):
    for est in estudiantes:
        for first_name, last_name in est.items():
            print(first_name, "-",last_name)

    estudiantes = [
    {'first_name': 'Michael', 'last_name': 'Jordan'},
    {'first_name': 'John', 'last_name': 'Rosales'},
    {'first_name': 'Mark', 'last_name': 'Guillen'},
    {'first_name': 'KB', 'last_name': 'Tonel'}
]
iterar_diccionarios(estudiantes)

print("---")

#3.Obtener valores de una lista de diccionarios
#nombres
def iterar_diccionarios2(name, estudiantes):
    for est in estudiantes:
        for name in est:
            print(est[name])

    estudiantes = [
    {'name': 'Michael', 'last_name': 'Jordan'},
    {'name': 'John', 'last_name': 'Rosales'},
    {'name': 'Mark', 'last_name': 'Guillen'},
    {'name': 'KB', 'last_name': 'Tonel'}
]
iterar_diccionarios2('name', estudiantes)

#apellidos
def iterar_diccionarios2(last_name, estudiantes):
    for est in estudiantes:
        for clave in est:
            if clave == last_name:
                print(est[clave])

    estudiantes = [
    {'name': 'Michael', 'last_name': 'Jordan'},
    {'name': 'John', 'last_name': 'Rosales'},
    {'name': 'Mark', 'last_name': 'Guillen'},
    {'name': 'KB', 'last_name': 'Tonel'}
]
iterar_diccionarios2('last_name', estudiantes)

print("---")

#4. Iterar a través de un diccionario con valores de lista
def info(dojo):
    for key, value in dojo.items():
        print(f"{key} {len(value)}")
        for item in value:
            print(item)

dojo = {
    'ubicaciones': ['San Jose', 'Seattle', 'Dallas', 'Chicago', 'Tulsa', 'DC', 'Burbank'],
    'instructores': ['Michael', 'Amy', 'Eduardo', 'Josh', 'Graham', 'Patrick', 'Minh', 'Devon']
}
info(dojo)